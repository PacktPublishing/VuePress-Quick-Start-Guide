# Hello World! 
This is sample VuePress site about coffee.

## What is This About? 
This site has been built as part of the VuePress Quick Start Guide book, authored by, yours truly, Sufyan bin Uzayr. 

In order to understand the site structure, you should look at Chapter Four of the book. 

You can find additional information about this site's code at the GitHub page. The link is in the navbar itself. :) 

### More Info 
VuePress is a static site generator powered by Vue.js 

This site was built to showcase how to develop simple sites using VuePress. You can learn more about VuePress [here](https://vuepress.vuejs.org/). 

If you have any queries, the author can be found [on this page](http://sufyanism.com)
